# EasyWebServer
An easy-to-use web server for Arduino.

The purpose of this web server is not to be the most powerful, but to be very easy to use.

Have you tried the default web server example of the Ethernet library? And whant to add more 
than one page (respose)? Then this is you next stop!

This server will parse the HTTP request and deliver different response based on the URL given
by the client.

It will also do some very basic validation of the incoming reguest and respond with a 
404 Not Found message if the URL was not implemented.

See http://techblog.se/2016/09/22/easywebserver/ for a quick taste.

